package com.example.edjustice.ui;

import androidx.fragment.app.Fragment;

public class Advocacy extends Fragment {
}
