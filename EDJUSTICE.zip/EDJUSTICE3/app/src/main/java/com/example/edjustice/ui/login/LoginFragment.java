package com.example.edjustice.ui.login;

import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {
}
