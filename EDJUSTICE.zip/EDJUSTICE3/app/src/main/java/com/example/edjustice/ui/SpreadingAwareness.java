package com.example.edjustice.ui;

import androidx.fragment.app.Fragment;

public class SpreadingAwareness extends Fragment {
}
